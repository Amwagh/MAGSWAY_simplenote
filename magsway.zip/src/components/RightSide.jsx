import React from 'react';
import "./style.css"
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css"

const RightSide = () => {
  return (
    <>
      <div>
        <textarea className='note_section' rows="4" cols="110">
          At w3schools.com you will learn how to make a website. They offer free
          tutorials in all web development technologies.
        </textarea>
      </div>
    </>
  );
}

export default RightSide
