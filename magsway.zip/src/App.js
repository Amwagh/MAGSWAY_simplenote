import React from 'react';
import "./App.css"
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import LeftSide from './components/LeftSide';
import RightSide from './components/RightSide';
import Header from './components/Header';



const App = () => {
  return (
    <>
      <Header />
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-4">
            <LeftSide/>
          </div>
          <div className="col-md-8">
            <RightSide/>
          </div>
        </div>
      </div>
    </>
  );
}

export default App